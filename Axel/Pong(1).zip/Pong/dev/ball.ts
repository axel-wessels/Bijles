class Ball{
    private html:HTMLElement

    private xPos:number
    private yPos:number

    private xSpeed:number
    private ySpeed:number

    constructor(){
        //making the ball
        this.html = document.createElement("ball")
        document.body.appendChild(this.html)

        //xpos & ypos
        this.xPos = Math.random()*window.innerWidth
        this.yPos = Math.random()*window.innerHeight

        //speed
        this.xSpeed = 10
        this.ySpeed = 10
    }

    public move():void{
        this.xPos += this.xSpeed
        this.yPos += this.ySpeed

        this.checkCollision()
    }

    private draw():void{
        this.html.style.transform = `translate(${this.xPos}px, ${this.yPos}px)`
    }

    public checkCollision(){
        if(this.xPos >= (window.innerWidth - this.getRectangle().width) || this.xPos <= 0){
            this.xSpeed *= -1
        }
        if(this.yPos >= (window.innerHeight - this.getRectangle().height) || this.yPos <= 0){
            this.ySpeed *= -1
        }

        this.draw()
    }

    public getRectangle():ClientRect{
        return this.html.getBoundingClientRect()
    }
}